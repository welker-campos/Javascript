/**
 * Exemplos de funções Simples
 * @author Welker Campos 
 */


 function helloWorld(){
    let nome
    nome= prompt ('Qual é seu nome')
    alert('Hello '+ nome)
 }